// Copyright Crucible Networks Ltd 2023. All Rights Reserved.

#include "ElizaPluginSettings.h"
#include "Runtime/Launch/Resources/Version.h"
