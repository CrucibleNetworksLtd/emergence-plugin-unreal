// Copyright Crucible Networks Ltd 2025. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintAsyncActionBase.h"
#include "Interfaces/IHttpRequest.h"
#include "MessageAgent.generated.h"
/**
 * 
 */
UCLASS()
class ELIZA_API UMessageAgent : public UBlueprintAsyncActionBase
{
	GENERATED_BODY()
	
public:
	UFUNCTION(BlueprintCallable, meta = (BlueprintInternalUseOnly = "true"), Category = "Eliza")
	static UMessageAgent* MessageAgent(FString AgentId, FString Message);

	virtual void Activate() override;

	DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FOnMessageAgentCompleted, bool, Success, FString, User, FString, Text, FString, Action);

	UPROPERTY(BlueprintAssignable)
	FOnMessageAgentCompleted OnMessageAgentCompleted;
private:
	void MessageAgent_HttpRequestComplete(FHttpRequestPtr HttpRequest, FHttpResponsePtr HttpResponse, bool bSucceeded);

	FString AgentId, Message;
};
