// Copyright Crucible Networks Ltd 2022. All Rights Reserved.

#include "EmergencePluginSettings.h"

UEmergencePluginSettings::UEmergencePluginSettings(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{

}